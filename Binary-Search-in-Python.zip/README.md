# Binary-Search-in-Python

#Binary Search algorithm is a divide and search algorithm which helps yoy to search and ordered list very rapidly.
